#!/bin/bash
flatpak run io.mrarm.mcpelauncher
