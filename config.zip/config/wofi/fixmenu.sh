#!/bin/bash
# Меню закріплених програм для Wofi

# Формат: <Назва>|<Іконка>|<Команда>

echo "Термінал (Wezterm)|terminal|wezterm"
echo "Браузер (Firefox)|web-browser|firefox"
echo "Файловий менеджер (Nautilus)|folder-open|nautilus"
echo "Налаштування (Appearance)|applications-system|nwg-look"
echo "Завершення сесії|system-shutdown|hyprctl dispatch exit"