#!/bin/bash
firefox "https://www.youtube.com/results?search_query=$(url_encode "$@")"