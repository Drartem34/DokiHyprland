#!/bin/bash
firefox "https://www.google.com/search?q=$(url_encode "$@")"