import subprocess
from gi.repository import Gtk, Gdk
from ignis import widgets, app

def PowerMenu():
    
    # Змінна для збереження поточного вибору (0 - перша кнопка)
    state = {"index": 0}
    buttons = []

    def run_command(cmd):
        subprocess.Popen(cmd, shell=True)
        app.get_window("powermenu").set_visible(False)

    # Функція, яка оновлює вигляд ВСІХ кнопок
    def update_selection(new_index):
        state["index"] = new_index
        for i, btn_data in enumerate(buttons):
            is_active = (i == new_index)
            widget = btn_data["widget"]
            hover_color = btn_data["color"]
            icon = btn_data["icon"]
            lbl = btn_data["label"]

            if is_active:
                # АКТИВНИЙ СТИЛЬ
                try: widget.set_cursor(Gdk.Cursor.new_from_name("pointer", None))
                except: pass
                
                widget.set_style(f"""
                    min-width: 120px; min-height: 120px; border-radius: 16px;
                    background-color: {hover_color}; 
                    border: 1px solid {hover_color};
                    transition: 0.2s; transform: scale(1.05);
                """)
                icon.set_style("color: #11111b; transition: 0.2s;")
                lbl.set_style("font-weight: bold; font-size: 14px; margin-top: 10px; color: #11111b; transition: 0.2s;")
            else:
                # НЕАКТИВНИЙ СТИЛЬ
                try: widget.set_cursor(None)
                except: pass
                
                widget.set_style(f"""
                    min-width: 120px; min-height: 120px; border-radius: 16px;
                    background-color: rgba(255, 255, 255, 0.05);
                    border: 1px solid rgba(255, 255, 255, 0.1); 
                    transition: 0.2s; transform: scale(1.0);
                """)
                icon.set_style("color: #ffffff; transition: 0.2s;")
                lbl.set_style("font-weight: bold; font-size: 14px; margin-top: 10px; color: #ffffff; transition: 0.2s;")

    def PowerButton(icon_name, label_text, cmd, hover_color, index):
        icon = widgets.Icon(image=icon_name, pixel_size=48, style="color: #ffffff; transition: 0.2s;")
        lbl = widgets.Label(label=label_text, style="font-weight: bold; font-size: 14px; margin-top: 10px; color: #ffffff; transition: 0.2s;")
        
        box = widgets.Box(
            vertical=True,
            css_classes=["clickable-box"],
            style="min-width: 120px; min-height: 120px;", # Базовий стиль перезапишеться update_selection
            child=[
                widgets.Box(hexpand=True, vexpand=True, valign="center", halign="center", child=[icon]),
                lbl
            ]
        )

        # 1. Мишка (Клік)
        gesture = Gtk.GestureClick()
        gesture.connect("released", lambda x, n, a, b: run_command(cmd))
        box.add_controller(gesture)

        # 2. Мишка (Наведення) - просто оновлюємо індекс
        motion = Gtk.EventControllerMotion()
        motion.connect("enter", lambda c, x, y: update_selection(index))
        box.add_controller(motion)

        # Зберігаємо дані про кнопку
        buttons.append({
            "widget": box,
            "icon": icon,
            "label": lbl,
            "color": hover_color,
            "cmd": cmd
        })

        return box

    # --- СТВОРЕННЯ КНОПОК ---
    btn_off = PowerButton("system-shutdown-symbolic", "Вимкнути", "systemctl poweroff", "#f38ba8", 0)
    btn_reb = PowerButton("system-reboot-symbolic", "Перезапуск", "systemctl reboot", "#f9e2af", 1)
    btn_slp = PowerButton("weather-clear-night-symbolic", "Сон", "systemctl suspend", "#89b4fa", 2)

    # --- КАРТКА ---
    card = widgets.Box(
        vertical=True,
        style="background-color: #1e1e2e81; border: 2px solid #313244; border-radius: 20px; padding: 25px;",
        child=[
            widgets.Label(label="Goodbye!", style="font-size: 20px; font-weight: bold; margin-bottom: 20px; color: #ffffff;"),
            widgets.Box(spacing=20, child=[btn_off, btn_reb, btn_slp])
        ]
    )

    overlay = widgets.Box(
        style="background-color: rgba(0, 0, 0, 0);", 
        hexpand=True, vexpand=True, halign="fill", valign="fill",
        child=[widgets.Box(halign="center", valign="center", hexpand=True, vexpand=True, child=[card])]
    )
    
    click_gesture = Gtk.GestureClick()
    click_gesture.connect("released", lambda x,n,a,b: app.get_window("powermenu").set_visible(False))
    overlay.add_controller(click_gesture)

    window = widgets.Window(
        name="powermenu",
        namespace="ignis_powermenu",
        anchor=["top", "left", "right", "bottom"],
        exclusivity="ignore",
        layer="overlay",
        visible=False,
        kb_mode="exclusive", # Блокування клавіатури
        style="background-color: transparent;",
        child=overlay
    )

    # --- ГОЛОВНИЙ КОНТРОЛЕР ---
    key_ctl = Gtk.EventControllerKey()
    
    def on_key_pressed(controller, keyval, keycode, state_mask):
        curr = state["index"]
        
        if keyval in [Gdk.KEY_Left, Gdk.KEY_Up]:
            new_idx = (curr - 1) % len(buttons)
            update_selection(new_idx)
            return True
            
        elif keyval in [Gdk.KEY_Right, Gdk.KEY_Down, Gdk.KEY_Tab]:
            new_idx = (curr + 1) % len(buttons)
            update_selection(new_idx)
            return True
            
        elif keyval in [Gdk.KEY_Return, Gdk.KEY_KP_Enter, Gdk.KEY_space]:
            run_command(buttons[curr]["cmd"])
            return True
            
        elif keyval == Gdk.KEY_Escape:
            window.set_visible(False)
            return True
            
        return False

    key_ctl.connect("key-pressed", on_key_pressed)
    window.add_controller(key_ctl)

    # При відкритті - скидаємо на першу кнопку
    window.connect("show", lambda x: update_selection(0))

    return window

def setup(app):
    app.add_window(window=PowerMenu(), window_name="powermenu")