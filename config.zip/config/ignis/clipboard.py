import subprocess
import os
import re
import shutil
import json
import urllib.parse
from pathlib import Path
from gi.repository import Gio, Gtk, Gdk, Gtk4LayerShell, GObject
from ignis import widgets, utils

# --- НАЛАШТУВАННЯ ---
MAX_ITEMS = 30
CACHE_DIR = "/tmp/ignis_clipboard_cache"
WINDOW_WIDTH = 320
WINDOW_HEIGHT = 450

if not os.path.exists(CACHE_DIR):
    os.makedirs(CACHE_DIR)

# Глобальні змінні
clip_window = None
clip_box = None
content_box = None
start_margin_x = 0
start_margin_y = 0

def clean_text(text):
    if not text: return ""
    return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text).strip()

def get_cached_image(item_id):
    file_path = os.path.join(CACHE_DIR, f"{item_id}.png")
    if os.path.exists(file_path): return file_path
    try:
        with open(file_path, "wb") as f:
            subprocess.run(f"cliphist decode {item_id}", shell=True, stdout=f)
        return file_path
    except: return None

def get_history():
    items = []
    try:
        result = subprocess.run(f"cliphist list | head -n {MAX_ITEMS}", shell=True, capture_output=True, text=True, errors='replace')
        if not result.stdout: return []
        
        for line in result.stdout.splitlines():
            parts = line.split("\t", 1)
            if len(parts) < 2: continue
            item_id, raw_text = parts[0], parts[1]
            
            is_image = "binary data" in raw_text.lower() and len(raw_text) < 150
            is_file = False
            display_text = raw_text

            if not is_image:
                decoded = clean_text(raw_text)
                if decoded.startswith("file://"):
                    is_file = True
                    try:
                        path_str = urllib.parse.unquote(decoded.replace("file://", "").strip())
                        display_text = os.path.basename(path_str)
                    except: display_text = decoded
                elif decoded.startswith("/") and os.path.exists(decoded):
                    is_file = True
                    display_text = os.path.basename(decoded)
                else:
                    display_text = decoded[:50] + "..." if len(decoded) > 50 else decoded
            
            items.append({"id": item_id, "text": display_text, "is_image": is_image, "is_file": is_file})
    except: pass
    return items

def restore_item(item_id, is_file):
    try:
        if is_file:
            subprocess.Popen(f"cliphist decode {item_id} | wl-copy -t text/uri-list", shell=True)
        else:
            subprocess.Popen(f"cliphist decode {item_id} | wl-copy", shell=True)
    except: pass

def delete_item(item_id):
    try:
        subprocess.Popen(f"cliphist delete {item_id}", shell=True)
        p = os.path.join(CACHE_DIR, f"{item_id}.png")
        if os.path.exists(p): os.remove(p)
        populate_list()
    except: pass

def clear_history():
    try:
        subprocess.Popen("cliphist wipe", shell=True)
        shutil.rmtree(CACHE_DIR)
        os.makedirs(CACHE_DIR)
        populate_list()
    except: pass

# --- LOGIC FOR DROPPING ---
def on_drop_safe(target, value, x, y):
    try:
        if value:
            # Примусово конвертуємо в рядок
            text_val = str(value).strip()
            print(f"Dropped: {text_val}")
            
            if "file://" in text_val:
                # Очищаємо URI
                clean_uri = text_val.splitlines()[0].strip()
                cmd = f"echo -n '{clean_uri}' | wl-copy"
                subprocess.run(cmd, shell=True)
                
                if content_box:
                    content_box.set_style("background-color: rgba(166, 227, 161, 0.2); border: 2px solid #a6e3a1; border-radius: 16px; padding: 12px;")
                    utils.Timeout(300, lambda: content_box.set_style("background-color: #1e1e2e; border: 1px solid #313244; border-radius: 16px; padding: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.5);"))
                
                utils.Timeout(500, populate_list)
                return True
    except Exception as e: 
        print(f"Drop Handler Error: {e}")
    return False

def on_drag_enter(target, x, y):
    if content_box:
        content_box.set_style("background-color: rgba(137, 180, 250, 0.2); border: 2px solid #89b4fa; border-radius: 16px; padding: 12px;")
    return Gdk.DragAction.COPY

def on_drag_leave(target):
    if content_box:
        content_box.set_style("background-color: #1e1e2e; border: 1px solid #313244; border-radius: 16px; padding: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.5);")

def ClipboardItem(data, window):
    item_id = data["id"]
    is_file = data["is_file"]
    content = None
    style = "padding: 10px; margin-bottom: 5px; border-radius: 10px; transition: 0.2s;"
    bg = "background-color: rgba(49, 50, 68, 0.6); border: 1px solid rgba(255,255,255,0.05);"

    if data["is_image"]:
        path = get_cached_image(item_id)
        if path:
            content = widgets.Box(style="min-height: 120px;")
            bg = f"background-image: url('file://{path}'); background-size: cover; background-position: center; border: 1px solid rgba(137, 180, 250, 0.5);"
            style = "padding: 0; margin-bottom: 5px; border-radius: 10px;"
    elif is_file:
        content = widgets.Box(spacing=10, child=[
            widgets.Icon(image="folder-documents-symbolic", pixel_size=24, style="color: #f9e2af;"),
            widgets.Box(vertical=True, valign="center", child=[
                widgets.Label(label="Файл", style="font-size: 9px; color: #a6adc8;", halign="start"),
                widgets.Label(label=data["text"], style="font-weight: bold; color: #cdd6f4;", ellipsize="start", max_width_chars=20)
            ])
        ])
        bg = "background-color: rgba(49, 50, 68, 0.8); border: 1px dashed #f9e2af;"
    else:
        content = widgets.Box(spacing=10, child=[
            widgets.Icon(image="text-x-generic-symbolic", pixel_size=16, style="opacity: 0.7;"),
            widgets.Label(label=data["text"], style="color: #cdd6f4;", ellipsize="end", max_width_chars=25)
        ])

    box = widgets.Box(css_classes=["clickable-box"], style=f"{style} {bg}", child=[content] if content else [])
    
    gesture = Gtk.GestureClick()
    gesture.set_button(0)
    gesture.connect("released", lambda c,n,x,y: restore_item(item_id, is_file) if c.get_current_button()==1 else delete_item(item_id))
    box.add_controller(gesture)
    
    def on_hov(c, x, y): box.set_cursor(Gdk.Cursor.new_from_name("pointer", None)); box.set_style(f"{style} {bg} filter: brightness(1.3); border-color: #89b4fa;")
    def on_unhov(c): box.set_cursor(None); box.set_style(f"{style} {bg}")
    m = Gtk.EventControllerMotion(); m.connect("enter", on_hov); m.connect("leave", on_unhov); box.add_controller(m)
    return box

def populate_list():
    child = clip_box.get_first_child()
    while child: clip_box.remove(child); child = clip_box.get_first_child()
    items = get_history()
    if not items: clip_box.append(widgets.Label(label="Перетягни файл сюди...", style="color: #6c7086; margin: 20px; font-size: 12px;"))
    else:
        for i in items: clip_box.append(ClipboardItem(i, clip_window))

def setup(app_instance):
    global clip_window, clip_box, content_box, start_margin_x, start_margin_y

    clip_box = widgets.Box(vertical=True)
    scroll = widgets.Scroll(vexpand=True, hexpand=True, child=clip_box, style="min-height: 200px;")

    btn_box = widgets.Button(
        child=widgets.Label(label="Очистити", style="color: #f38ba8; font-weight: bold; font-size: 11px;"),
        on_click=lambda x: clear_history(),
        style="background: transparent; border: none; box-shadow: none; padding: 0;"
    )

    header = widgets.Box(
        style="padding-bottom: 8px; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 10px;",
        child=[
            widgets.Label(label="Буфер обміну", style="font-size: 14px; font-weight: bold; color: #cdd6f4;", halign="start", hexpand=True),
            btn_box
        ]
    )

    dg = Gtk.GestureDrag()
    def d_beg(g,x,y):
        global start_margin_x, start_margin_y
        start_margin_x = Gtk4LayerShell.get_margin(clip_window, 0)
        start_margin_y = Gtk4LayerShell.get_margin(clip_window, 2)
        header.set_cursor(Gdk.Cursor.new_from_name("grabbing", None))
    def d_upd(g,ox,oy):
        Gtk4LayerShell.set_margin(clip_window, 0, start_margin_x + int(ox))
        Gtk4LayerShell.set_margin(clip_window, 2, start_margin_y + int(oy))
    def d_end(g,ox,oy): header.set_cursor(Gdk.Cursor.new_from_name("grab", None))
    dg.connect("drag-begin", d_beg); dg.connect("drag-update", d_upd); dg.connect("drag-end", d_end); header.add_controller(dg)
    
    hm = Gtk.EventControllerMotion()
    hm.connect("enter", lambda c,x,y: header.set_cursor(Gdk.Cursor.new_from_name("grab", None)))
    hm.connect("leave", lambda c: header.set_cursor(None))
    header.add_controller(hm)

    content_box = widgets.Box(
        vertical=True,
        style="background-color: #1e1e2e81; border: 1px solid #313244; border-radius: 16px; padding: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.5);",
        child=[header, scroll]
    )

    # --- SAFE DROP TARGET ---
    # Загортаємо в try/except, щоб вікно не падало, якщо система не підтримує цей тип
    try:
        drop_target = Gtk.DropTarget.new(type=GObject.TYPE_STRING, actions=Gdk.DragAction.COPY)
        drop_target.connect("drop", on_drop_safe)
        drop_target.connect("enter", on_drag_enter)
        drop_target.connect("leave", on_drag_leave)
        content_box.add_controller(drop_target)
    except Exception as e:
        print(f"CRITICAL: Failed to init DropTarget: {e}")

    clip_window = widgets.Window(
        name="clipboard",
        namespace="ignis_clipboard",
        anchor=["top", "left"],
        width_request=WINDOW_WIDTH,
        height_request=WINDOW_HEIGHT,
        exclusivity="ignore",
        layer="overlay",
        visible=False,
        kb_mode="on_demand", 
        css_classes=["unset-window"],
        style="background-color: transparent;", 
        child=content_box
    )

    key_controller = Gtk.EventControllerKey()
    key_controller.connect("key-pressed", lambda c,k,kc,s: clip_window.set_visible(False) if k==Gdk.KEY_Escape else False)
    clip_window.add_controller(key_controller)

    def on_window_show(window, param):
        if window.visible:
            populate_list()
            try:
                out = subprocess.check_output("hyprctl cursorpos", shell=True).decode().strip()
                cx, cy = map(int, out.split(","))
                mons = json.loads(subprocess.check_output("hyprctl monitors -j", shell=True))
                am = next((m for m in mons if m["focused"]), mons[0])
                tx = (cx - am["x"]) + 15
                ty = (cy - am["y"]) + 15
                if tx + WINDOW_WIDTH > am["width"]: tx = am["width"] - WINDOW_WIDTH - 20
                if ty + WINDOW_HEIGHT > am["height"]: ty = am["height"] - WINDOW_HEIGHT - 50
                Gtk4LayerShell.set_margin(window, 0, tx)
                Gtk4LayerShell.set_margin(window, 2, ty)
            except: 
                Gtk4LayerShell.set_margin(window, 0, 100)
                Gtk4LayerShell.set_margin(window, 2, 100)

    clip_window.connect("notify::visible", on_window_show)
    app_instance.add_window(window=clip_window, window_name="clipboard")
    print("--- Bulletproof Clipboard Loaded ---")