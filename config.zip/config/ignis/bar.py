import datetime
import subprocess
import os
from ignis import widgets, utils
from ignis.app import IgnisApp
from ignis.services.audio import AudioService
from gi.repository import Gtk, Gdk

audio = AudioService.get_default()

def run_async(cmd):
    subprocess.Popen(cmd, shell=True)

# --- БАЗОВА КНОПКА ---
def BarButton(child, on_click, on_right_click=None, css_classes=[]):
    box = widgets.Box(
        child=[child],
        css_classes=["bar-btn", "unset"] + css_classes,
        style="margin: 0 2px; border-radius: 5px; transition: 0.2s;"
    )
    
    gesture = Gtk.GestureClick()
    gesture.connect("released", lambda x, n, a, b: on_click())
    box.add_controller(gesture)

    if on_right_click:
        right_click = Gtk.GestureClick()
        right_click.set_button(3)
        right_click.connect("released", lambda x, n, a, b: on_right_click())
        box.add_controller(right_click)
    
    # Ефект наведення
    motion = Gtk.EventControllerMotion()
    motion.connect("enter", lambda c, x, y: box.set_cursor(Gdk.Cursor.new_from_name("pointer", None)))
    motion.connect("leave", lambda c: box.set_cursor(None))
    box.add_controller(motion)
    
    return box

# --- MACOS МЕНЮ (File Edit View...) ---
def MenuLabel(text):
    return BarButton(
        child=widgets.Label(label=text, style="font-weight: 500; color: white; font-size: 13px; padding: 0 4px;"),
        on_click=lambda: print(f"Clicked {text}"), 
        css_classes=["menu-item"]
    )

def GlobalMenuWidget():
    return widgets.Box(
        spacing=0,
        child=[
            MenuLabel("File"),
            MenuLabel("Edit"),
            MenuLabel("View"),
            MenuLabel("Go"),
            MenuLabel("Window"),
            MenuLabel("Help")
        ]
    )

# --- ГОДИННИК І КАЛЕНДАР ---
def ClockWidget(app):
    label = widgets.Label(style="font-weight: bold; color: white;")
    
    def update_time(*args):
        label.set_label(datetime.datetime.now().strftime("%a %d %b %H:%M"))
    
    utils.Poll(1000, update_time)
    
    return BarButton(
        child=label, 
        on_click=lambda: app.toggle_window("calendar_popup")
    )

def CalendarWindow():
    return widgets.Window(
        name="calendar_popup",
        anchor=["top"],
        layer="top",
        visible=False,
        style="margin-top: 38px;", 
        child=widgets.Box(
            style="background-color: #1e1e2e; border-radius: 12px; padding: 10px; border: 1px solid rgba(255,255,255,0.1);",
            child=[widgets.Calendar(style="color: white;")]
        )
    )

# --- БАТАРЕЯ ---
def BatteryWidget():
    icon = widgets.Icon(pixel_size=16, style="color: white;")
    label = widgets.Label(style="color: white; font-weight: bold; margin-right: 5px;")
    box = widgets.Box(child=[label, icon], visible=False) 

    def update(*args):
        try:
            path = ""
            if os.path.exists("/sys/class/power_supply/BAT0"): path = "/sys/class/power_supply/BAT0"
            elif os.path.exists("/sys/class/power_supply/BAT1"): path = "/sys/class/power_supply/BAT1"
            
            if path:
                box.set_visible(True)
                with open(f"{path}/capacity", "r") as f: cap = int(f.read().strip())
                with open(f"{path}/status", "r") as f: status = f.read().strip()
                
                label.set_label(f"{cap}%")
                
                icon_name = f"battery-level-{cap - (cap % 10)}-symbolic"
                if status == "Charging": icon_name += "-charging"
                
                icon.set_image(icon_name)
            else:
                # Заглушка для ПК (можна прибрати else, щоб сховати)
                box.set_visible(True) 
                label.set_label("100%")
                icon.set_image("battery-level-100-charged-symbolic")
                
        except: pass

    utils.Poll(5000, update)
    return box

# --- ІНШІ ВІДЖЕТИ ---
def VolumeWidget():
    icon = widgets.Icon(pixel_size=18, style="color: white;")
    def update(*args):
        if audio.speaker.is_muted: icon.set_image("audio-volume-muted-symbolic")
        elif audio.speaker.volume > 66: icon.set_image("audio-volume-high-symbolic")
        else: icon.set_image("audio-volume-low-symbolic")
    
    audio.speaker.connect("notify::volume", update)
    audio.speaker.connect("notify::is-muted", update)
    update()
    return BarButton(child=icon, on_click=lambda: run_async("pavucontrol"))

def NetworkWidget():
    return BarButton(
        child=widgets.Icon(image="network-wireless-symbolic", pixel_size=18, style="color: white;"),
        on_click=lambda: run_async("kitty -e nmtui")
    )

def ControlCenterBtn(app):
    return BarButton(
        child=widgets.Icon(image="view-grid-symbolic", pixel_size=18, style="color: white;"),
        on_click=lambda: app.toggle_window("control_center")
    )

# --- ГОЛОВНА ФУНКЦІЯ ---
def create_bar(app):
    print("--- Creating macOS Bar ---")

    left_box = widgets.Box(spacing=6, child=[
        BarButton(
            child=widgets.Icon(image="start-here-symbolic", pixel_size=18, style="color: white;"),
            on_click=lambda: run_async("wofi --show drun")
        ),
        widgets.Label(label="Hyprland", style="font-weight: 800; color: white; margin-right: 12px;"),
        GlobalMenuWidget() 
    ])

    center_box = ClockWidget(app)

    right_box = widgets.Box(spacing=5, child=[
        VolumeWidget(),
        BatteryWidget(), 
        NetworkWidget(),
        ControlCenterBtn(app)
    ])

    bar_window = widgets.Window(
        name="top_bar",
        anchor=["top", "left", "right"],
        exclusivity="exclusive",
        layer="top",
        visible=True,
        child=widgets.CenterBox(
            style="background-color: rgba(30, 30, 46, 0.95); min-height: 32px; padding: 0 15px; border-bottom: 1px solid rgba(255,255,255,0.1);",
            start_widget=left_box,
            center_widget=center_box,
            end_widget=right_box
        )
    )

    app.add_window(bar_window, "top_bar")
    app.add_window(CalendarWindow(), "calendar_popup")