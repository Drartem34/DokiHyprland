from gi.repository import Gtk, Gdk
from ignis import widgets
from ignis.services.audio import AudioService

audio = AudioService.get_default()

# --- СЛОВНИК ІКОНОК ---
ICON_MAP = {
    "firefox": "firefox",
    "chrome": "google-chrome",
    "chromium": "chromium-browser",
    "spotify": "spotify-client",
    "discord": "discord",
    "telegram": "telegram",
    "code": "visual-studio-code",
    "vlc": "vlc",
    "obs": "obs",
    "steam": "steam"
}

# --- УНІВЕРСАЛЬНИЙ КЛІКАБЕЛЬНИЙ БЛОК ---
# Це замінює звичайні кнопки, щоб точно ловити кліки
def InteractiveBox(child, on_click, css_classes=[], style=""):
    box = widgets.Box(
        child=[child],
        css_classes=["clickable-box"] + css_classes,
        style=f"transition: 0.2s; border-radius: 12px; {style}"
    )

    # 1. Обробка кліку (Pressed - спрацьовує миттєво при натисканні)
    gesture = Gtk.GestureClick()
    gesture.connect("pressed", lambda x, n, a, b: on_click(box))
    box.add_controller(gesture)

    # 2. Обробка наведення (зміна кольору і курсора)
    def on_enter(c, x, y):
        try:
            cursor = Gdk.Cursor.new_from_name("pointer", None)
            box.set_cursor(cursor)
        except: pass
        # Трохи світліший фон при наведенні
        box.set_style(f"transition: 0.2s; border-radius: 12px; background-color: rgba(255, 255, 255, 0.1); {style}")
    
    def on_leave(c):
        try:
            box.set_cursor(None)
        except: pass
        # Повертаємо старий фон
        box.set_style(f"transition: 0.2s; border-radius: 12px; {style}")

    motion = Gtk.EventControllerMotion()
    motion.connect("enter", on_enter)
    motion.connect("leave", on_leave)
    box.add_controller(motion)

    return box

# --- БЛОК ВИБОРУ ПРИСТРОЮ ---
def DeviceSelector(title, icon_name, stream_type):
    # Контейнер для списку
    list_box = widgets.Box(vertical=True, spacing=5, style="margin-top: 5px; margin-bottom: 5px;")
    revealer = widgets.Revealer(transition_type="slide_down", child=list_box, reveal_child=False)
    
    status_label = widgets.Label(label="...", halign="start", style="font-size: 12px; color: #a6adc8;", ellipsize="end")
    arrow_icon = widgets.Icon(image="pan-down-symbolic", pixel_size=16, style="color: #bac2de;")

    # Функція перемикання (викликається при кліку)
    def set_device(dev):
        print(f"[CLICK] Setting device to: {dev.description}")
        try:
            dev.make_default()
        except Exception as e:
            print(f"Error setting device: {e}")

    def rebuild_list(*args):
        # Очищення
        child = list_box.get_first_child()
        while child:
            list_box.remove(child)
            child = list_box.get_first_child()

        if stream_type == "speaker":
            devices = audio.speakers
            active_dev = audio.speaker
        else:
            devices = audio.microphones
            active_dev = audio.microphone

        # Оновлення статусу
        if active_dev:
            status_label.set_label(active_dev.description or active_dev.name)
        else:
            status_label.set_label("No device")

        # Якщо пристроїв немає
        if not devices:
            list_box.append(widgets.Label(label="No devices found", style="color: #6c7086; font-size: 12px; margin: 5px;"))
            return

        # Генерація списку
        for dev in devices:
            is_active = (active_dev and dev.id == active_dev.id)
            
            name_style = "font-size: 13px; font-weight: bold; color: #a6e3a1;" if is_active else "font-size: 13px; color: #cdd6f4;"
            icon_style = "color: #a6e3a1;" if is_active else "color: #bac2de;"
            
            # Вміст рядка
            row_content = widgets.Box(spacing=10, child=[
                widgets.Icon(image=dev.icon_name or "audio-card-symbolic", pixel_size=16, style=icon_style),
                widgets.Label(label=dev.description, hexpand=True, halign="start", ellipsize="end", style=name_style),
                widgets.Icon(image="object-select-symbolic", pixel_size=16, style="color: #a6e3a1;", visible=is_active)
            ])
            
            # ОБГОРТКА: Використовуємо InteractiveBox замість Button
            # lambda x, d=dev: ... гарантує, що ми передаємо правильний device
            item_box = InteractiveBox(
                child=row_content,
                on_click=lambda x, d=dev: set_device(d),
                style="padding: 8px; background-color: rgba(0,0,0,0.2);"
            )
            list_box.append(item_box)

    # Підписки
    audio.connect(f"notify::{stream_type}s", rebuild_list)
    audio.connect(f"notify::{stream_type}", rebuild_list)
    rebuild_list()

    def toggle_list(x):
        is_open = revealer.get_reveal_child()
        revealer.set_reveal_child(not is_open)
        arrow_icon.set_image("pan-up-symbolic" if not is_open else "pan-down-symbolic")

    # Заголовок теж робимо через InteractiveBox
    header_content = widgets.Box(spacing=10, child=[
        widgets.Icon(image=icon_name, pixel_size=20, style="color: #cdd6f4;"),
        widgets.Box(vertical=True, valign="center", child=[
            widgets.Label(label=title, halign="start", style="font-weight: bold; font-size: 14px; color: #cdd6f4;"),
            status_label
        ]),
        widgets.Box(hexpand=True),
        arrow_icon
    ])

    header_btn = InteractiveBox(
        child=header_content,
        on_click=toggle_list,
        style="padding: 5px;"
    )

    return widgets.Box(vertical=True, child=[header_btn, revealer])

# --- РЯДОК ПРОГРАМИ ---
def AppStreamRow(stream):
    def resolve_icon(value):
        app_name = (stream.name or "").lower()
        for key, icon in ICON_MAP.items():
            if key in app_name: return icon
        return stream.icon_name or "application-x-executable"

    icon_widget = widgets.Icon(
        image=stream.bind("icon_name", resolve_icon),
        pixel_size=24,
        style="margin-right: 10px;"
    )
    
    scale = widgets.Scale(
        min=0, max=100, step=1, hexpand=True,
        css_classes=["b-slider"], 
        value=stream.bind("volume"),
        on_change=lambda x: stream.set_volume(x.value)
    )

    def toggle_mute(x):
        stream.set_is_muted(not stream.is_muted)

    mute_icon = widgets.Icon(
        image=stream.bind("is_muted", lambda m: "audio-volume-muted-symbolic" if m else "audio-volume-high-symbolic"),
        pixel_size=16
    )

    mute_btn = InteractiveBox(
        child=mute_icon, 
        on_click=toggle_mute, 
        style="min-width: 32px; min-height: 32px; padding: 8px; background-color: rgba(69, 71, 90, 0.6);"
    )

    return widgets.Box(
        spacing=10, 
        style="margin-bottom: 8px; padding: 5px;",
        child=[
            icon_widget,
            widgets.Box(vertical=True, hexpand=True, child=[
                widgets.Label(
                    label=stream.name or stream.description or "Unknown App",
                    halign="start", ellipsize="end", 
                    style="font-size: 13px; font-weight: bold; color: #cdd6f4;", 
                    max_width_chars=25
                ),
                widgets.Box(spacing=10, valign="center", child=[scale, mute_btn])
            ])
        ]
    )

# --- ГОЛОВНИЙ ВІДЖЕТ ---
def MixerWidget():
    speakers = DeviceSelector("Outputs", "audio-speakers-symbolic", "speaker")
    microphones = DeviceSelector("Inputs", "audio-input-microphone-symbolic", "microphone")

    list_box = widgets.Box(vertical=True, spacing=5)
    
    apps_revealer = widgets.Revealer(transition_type="slide_down", child=list_box, reveal_child=True)
    apps_arrow = widgets.Icon(image="pan-up-symbolic", pixel_size=16, style="color: #bac2de;")

    def update_streams(*args):
        child = list_box.get_first_child()
        while child:
            list_box.remove(child)
            child = list_box.get_first_child()
        
        streams = audio.apps
        if not streams:
            list_box.append(widgets.Label(label="No apps playing", style="color: #6c7086; font-size: 12px; margin: 10px;"))
        else:
            for stream in streams:
                list_box.append(AppStreamRow(stream))

    audio.connect("notify::apps", update_streams)
    update_streams()

    def toggle_apps(x):
        is_open = apps_revealer.get_reveal_child()
        apps_revealer.set_reveal_child(not is_open)
        apps_arrow.set_image("pan-up-symbolic" if not is_open else "pan-down-symbolic")

    apps_header = widgets.Box(spacing=10, child=[
        widgets.Icon(image="preferences-desktop-sound-symbolic", pixel_size=20, style="color: #cdd6f4;"),
        widgets.Label(label="Applications", hexpand=True, halign="start", style="font-weight: bold; font-size: 14px; color: #cdd6f4;"),
        apps_arrow
    ])

    apps_btn = InteractiveBox(
        child=apps_header,
        on_click=toggle_apps,
        style="padding: 5px; margin-top: 10px;"
    )

    return widgets.Box(
        vertical=True,
        css_classes=["block", "dark", "wide"],
        style="padding: 12px;",
        spacing=5,
        child=[
            speakers,
            microphones,
            widgets.Box(style="min-height: 1px; background-color: rgba(255,255,255,0.1); margin: 5px 0;"),
            apps_btn,
            apps_revealer
        ]
    )