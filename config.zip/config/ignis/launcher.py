import subprocess
import os
import shutil
from gi.repository import Gtk, Gdk, Gio, GLib
from ignis import widgets, utils
from ignis.app import IgnisApp

# --- ЗАКРІПЛЕНІ ПРОГРАМИ ---
PINNED_APPS = [
    {"icon": "com.hypixel.HytaleLauncher", "cmd": "flatpak run com.hypixel.HytaleLauncher", "name": "Hytale"},
    {"icon": "com.visualstudio.code", "cmd": "code", "name": "VS Code"},
    {"icon": "steam", "cmd": "steam", "name": "Steam"},
    {"icon": "org.gnome.Nautilus", "cmd": "nautilus", "name": "Files"},
    {"icon": "firefox", "cmd": "firefox", "name": "Firefox"},
    {"icon": "kitty", "cmd": "kitty", "name": "Kitty"},
]

def Launcher():
    ignis_app = IgnisApp.get_default()

    # --- КЕШУВАННЯ ДАНИХ ---
    all_apps = []
    all_binaries = []
    filtered_results = []
    selected_index = 0
    app_cache = {}  # Кеш для швидкого пошуку
    update_timeout_id = None

    def load_data():
        """Завантаження даних з оптимізацією"""
        nonlocal all_apps, all_binaries, app_cache

        # hytale-----
        flatpak_user_path = os.path.expanduser("~/.local/share/flatpak/exports/share")
        flatpak_system_path = "/var/lib/flatpak/exports/share"
        
        current_dirs = os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share").split(":")
        
        if flatpak_user_path not in current_dirs:
            current_dirs.append(flatpak_user_path)
        if flatpak_system_path not in current_dirs:
            current_dirs.append(flatpak_system_path)
            
        os.environ["XDG_DATA_DIRS"] = ":".join(current_dirs)
        #------------
        
        # Завантаження застосунків
        try:
            apps = Gio.AppInfo.get_all()
            all_apps = [app for app in apps if app.should_show()]
            all_apps.sort(key=lambda x: (x.get_name() or "").lower())
            
            # Створення кешу для швидкого пошуку
            for app in all_apps:
                name = (app.get_name() or "").lower()
                exe = (app.get_executable() or "").lower()
                app_cache[name] = app
                if exe:
                    app_cache[exe] = app
        except Exception as e:
            print(f"Помилка завантаження застосунків: {e}")

        # Завантаження бінарних файлів
        bin_set = set()
        paths = os.environ.get("PATH", "").split(os.pathsep)
        
        for p in paths:
            if not os.path.isdir(p):
                continue
            try:
                for f in os.listdir(p):
                    if not f.startswith(".") and os.access(os.path.join(p, f), os.X_OK):
                        bin_set.add(f)
            except (PermissionError, OSError):
                continue
        
        all_binaries = sorted(bin_set)

    load_data()

    def close_launcher():
        """Закриття лаунчера"""
        entry.set_text("")
        ignis_app.get_window("launcher").set_visible(False)

    def run_cmd(cmd):
        """Запуск команди"""
        try:
            subprocess.Popen(
                cmd,
                shell=True,
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
        except Exception as e:
            print(f"Помилка запуску команди: {e}")
        finally:
            close_launcher()

    def launch_app(app_info):
        """Запуск застосунку"""
        try:
            app_info.launch([], None)
            close_launcher()
        except Exception as e:
            print(f"Помилка запуску застосунку: {e}")
            cmd = app_info.get_executable()
            if cmd:
                run_cmd(cmd)

    # --- UI КОМПОНЕНТИ ---
    results_box = widgets.Box(vertical=True, spacing=2)
    scroll_window = widgets.Scroll(height_request=400, child=results_box)

    base_entry_style = "font-size: 18px; padding: 12px; border-radius: 12px; background-color: rgba(255,255,255,0.08); color: white; margin-bottom: 10px;"
    
    entry = widgets.Entry(
        placeholder_text="Пошук...",
        css_classes=["launcher-entry"],
        style=base_entry_style + "border: 2px solid rgba(255,255,255,0.1);",
        hexpand=True
    )

    def create_result_row(icon_name, title, description, is_selected, callback):
        """Створення рядка результату"""
        bg = "rgba(255, 255, 255, 0.1)" if is_selected else "transparent"
        
        row = widgets.Box(
            style=f"background-color: {bg}; border-radius: 8px; padding: 8px;",
            spacing=12,
            child=[
                widgets.Icon(image=icon_name, pixel_size=32),
                widgets.Box(
                    vertical=True,
                    valign="center",
                    child=[
                        widgets.Label(
                            label=title,
                            style="color: white; font-weight: bold; font-size: 16px;",
                            halign="start",
                            ellipsize="end",
                            max_width_chars=50
                        ),
                        widgets.Label(
                            label=description,
                            style="color: #a6adc8; font-size: 12px;",
                            halign="start",
                            ellipsize="end",
                            max_width_chars=60
                        )
                    ]
                )
            ]
        )
        
        gesture = Gtk.GestureClick()
        gesture.connect("released", lambda *args: callback())
        row.add_controller(gesture)
        
        return row

    def clear_results():
        """Очищення результатів (оптимізовано)"""
        child = results_box.get_first_child()
        while child:
            next_child = child.get_next_sibling()
            results_box.remove(child)
            child = next_child

    def update_list():
        """Оновлення списку результатів (оптимізовано)"""
        nonlocal filtered_results, selected_index
        
        query = entry.get_text().strip()
        query_lower = query.lower()
        
        clear_results()
        filtered_results = []
        found_executables = set()

        # Обмеження кількості результатів
        max_apps = 50 if not query else 10
        max_bins = 10

        # 1. Пошук застосунків
        if query:
            # Оптимізований пошук з пріоритетом точних збігів
            exact_matches = []
            partial_matches = []
            
            for app_info in all_apps:
                if len(exact_matches) + len(partial_matches) >= max_apps:
                    break
                    
                name = app_info.get_name() or ""
                exe = app_info.get_executable() or ""
                name_lower = name.lower()
                exe_lower = exe.lower()
                
                if name_lower.startswith(query_lower):
                    exact_matches.append(app_info)
                elif query_lower in name_lower or query_lower in exe_lower:
                    partial_matches.append(app_info)
                
                if exe:
                    found_executables.add(exe.split()[0])
            
            matched_apps = exact_matches + partial_matches[:max_apps - len(exact_matches)]
        else:
            matched_apps = all_apps[:max_apps]

        # Додавання застосунків до результатів
        for app_info in matched_apps:
            name = app_info.get_name() or ""
            exe = app_info.get_executable() or ""
            icon = app_info.get_icon()
            
            filtered_results.append({
                "type": "app",
                "data": app_info,
                "title": name,
                "desc": exe or "Application",
                "icon": icon.to_string() if icon else "application-x-executable"
            })

        # 2. Пошук команд (тільки при запиті)
        if query and len(filtered_results) < max_apps:
            bin_matches = [
                b for b in all_binaries
                if query_lower in b.lower() and b not in found_executables
            ][:max_bins]
            
            for binary in bin_matches:
                filtered_results.append({
                    "type": "cmd",
                    "data": binary,
                    "title": binary,
                    "desc": "Термінальна команда",
                    "icon": "utilities-terminal-symbolic"
                })

            # Перевірка на точну команду
            if not filtered_results:
                exact_cmd = shutil.which(query.split()[0])
                if exact_cmd:
                    filtered_results.append({
                        "type": "cmd",
                        "data": query,
                        "title": f"Виконати: {query}",
                        "desc": exact_cmd,
                        "icon": "system-run-symbolic"
                    })

        # Оновлення стилю поля вводу
        if not query:
            border_color = "rgba(255,255,255,0.1)"
        elif filtered_results:
            border_color = "#a6e3a1"
        else:
            border_color = "#f38ba8"
        
        entry.set_style(base_entry_style + f"border: 2px solid {border_color};")

        # Скидання індексу при потребі
        if selected_index >= len(filtered_results):
            selected_index = 0

        # Додавання результатів до UI
        for i, item in enumerate(filtered_results):
            def create_callback(res):
                return lambda: (launch_app(res["data"]) if res["type"] == "app" else run_cmd(res["data"]))
            
            row = create_result_row(
                item["icon"],
                item["title"],
                item["desc"],
                i == selected_index,
                create_callback(item)
            )
            results_box.append(row)

    def on_text_change(widget, _):
        """Обробник зміни тексту з debounce"""
        nonlocal selected_index, update_timeout_id
        
        selected_index = 0
        
        # Debounce для швидкого друку
        if update_timeout_id:
            GLib.source_remove(update_timeout_id)
        
        update_timeout_id = GLib.timeout_add(50, lambda: (update_list(), False))

    entry.connect("notify::text", on_text_change)

    def scroll_to_selected():
        """Прокрутка до вибраного елемента"""
        if not filtered_results:
            return

        first_child = results_box.get_first_child()
        row_height = first_child.get_allocated_height() if first_child else 56
        row_height = max(row_height, 56)
        
        total_row_height = row_height + 2
        target_y = selected_index * total_row_height

        adj = scroll_window.get_vadjustment()
        current_y = adj.get_value()
        page_size = adj.get_page_size()

        if target_y < current_y:
            adj.set_value(target_y)
        elif (target_y + total_row_height) > (current_y + page_size):
            adj.set_value(target_y + total_row_height - page_size)

    def on_activation(widget):
        """Обробник Enter"""
        if filtered_results and selected_index < len(filtered_results):
            item = filtered_results[selected_index]
            if item["type"] == "app":
                launch_app(item["data"])
            else:
                run_cmd(item["data"])
        elif entry.get_text():
            run_cmd(entry.get_text())

    entry.connect("activate", on_activation)

    # --- ЗАКРІПЛЕНІ ЗАСТОСУНКИ ---
    pinned_box = widgets.Box(spacing=15, halign="center", style="margin-bottom: 15px;")
    
    for p in PINNED_APPS:
        icon_name = p["icon"]
        if icon_name == "com.visualstudio.code":
            theme = Gtk.IconTheme.get_for_display(Gdk.Display.get_default())
            if not theme.has_icon(icon_name):
                icon_name = "code"

        icon = widgets.Icon(image=icon_name, pixel_size=42)
        btn = widgets.Box(
            child=[icon],
            style="padding: 10px; border-radius: 12px; background-color: rgba(255,255,255,0.05);"
        )
        
        evt = Gtk.EventControllerMotion()
        evt.connect("enter", lambda c, x, y, b=btn: b.set_style(
            "padding: 10px; border-radius: 12px; background-color: rgba(255,255,255,0.15); transform: scale(1.1);"
        ))
        evt.connect("leave", lambda c, b=btn: b.set_style(
            "padding: 10px; border-radius: 12px; background-color: rgba(255,255,255,0.05);"
        ))
        btn.add_controller(evt)
        
        click = Gtk.GestureClick()
        click.connect("released", lambda *args, cmd=p["cmd"]: run_cmd(cmd))
        btn.add_controller(click)
        
        pinned_box.append(btn)

    # --- ОСНОВНИЙ КОНТЕЙНЕР ---
    card = widgets.Box(
        vertical=True,
        halign="center",
        valign="center",
        style="background-color: rgba(30, 30, 46, 0.6); border: 2px solid #cba6f7; border-radius: 15px; padding: 20px; min-width: 600px;",
        child=[
            entry,
            widgets.Label(
                label="Закріплені",
                halign="start",
                style="color: #a6adc8; font-size: 12px; margin-left: 5px;"
            ),
            pinned_box,
            widgets.Separator(style="background-color: rgba(255,255,255,0.1); margin-bottom: 10px;"),
            scroll_window
        ]
    )

    overlay = widgets.Box(
        style="background-color: transparent;",
        hexpand=True,
        vexpand=True,
        halign="fill",
        valign="fill",
        child=[
            widgets.Box(
                halign="center",
                valign="center",
                hexpand=True,
                vexpand=True,
                child=[card]
            )
        ]
    )
    
    bg_click = Gtk.GestureClick()
    bg_click.connect("released", lambda *args: close_launcher())
    overlay.add_controller(bg_click)

    # --- ОБРОБКА КЛАВІАТУРИ ---
    def on_key(controller, keyval, keycode, state):
        nonlocal selected_index
        
        if keyval == Gdk.KEY_Escape:
            close_launcher()
            return True

        if not filtered_results:
            return False

        if keyval == Gdk.KEY_Down:
            selected_index = (selected_index + 1) % len(filtered_results)
            update_list()
            scroll_to_selected()
            return True
        elif keyval == Gdk.KEY_Up:
            selected_index = (selected_index - 1) % len(filtered_results)
            update_list()
            scroll_to_selected()
            return True
        elif keyval in [Gdk.KEY_Return, Gdk.KEY_KP_Enter]:
            on_activation(None)
            return True

        return False

    key_ctl_window = Gtk.EventControllerKey()
    key_ctl_window.connect("key-pressed", on_key)
    
    key_ctl_entry = Gtk.EventControllerKey()
    key_ctl_entry.connect("key-pressed", on_key)
    entry.add_controller(key_ctl_entry)

    # --- ВІКНО ---
    window = widgets.Window(
        name="launcher",
        namespace="ignis_launcher",
        anchor=["top", "left", "right", "bottom"],
        exclusivity="ignore",
        layer="overlay",
        visible=False,
        kb_mode="exclusive",
        style="background-color: transparent;",
        child=overlay
    )
    
    window.add_controller(key_ctl_window)
    window.connect("show", lambda x: [
        entry.set_text(""),
        entry.grab_focus(),
        update_list()
    ])
    
    return window

def setup(app):
    app.add_window(window=Launcher(), window_name="launcher")