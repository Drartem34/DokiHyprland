import os
import subprocess
import urllib.parse
import hashlib
import threading
from concurrent.futures import ThreadPoolExecutor
import gi
from gi.repository import Gio, Gtk, Gdk, GdkPixbuf, GLib
from ignis import widgets

# --- НАЛАШТУВАННЯ ---
WALLPAPER_DIR = os.path.expanduser("~/Pictures/wallpapers")
CACHE_DIR = os.path.expanduser("~/.cache/ignis/wallpaper_thumbs")
THUMB_SIZE = 300  # Розмір мініатюр
MAX_WORKERS = 4   # Кількість паралельних потоків для генерації мініатюр

# Створюємо папку кешу
os.makedirs(CACHE_DIR, exist_ok=True)

# Глобальні змінні
wp_window = None
wp_flowbox = None
images_cache = []  # Кеш списку картинок
thumbnail_cache = {}  # Кеш згенерованих мініатюр

# --- Custom ClickableBox ---
def ClickableBox(child, on_click, css_classes=[], spacing=0):
    box = widgets.Box(
        child=[child] if child else [],
        css_classes=css_classes,
        spacing=spacing,
    )
    
    gesture = Gtk.GestureClick()
    gesture.connect("released", lambda x, n, a, b: on_click(box))
    box.add_controller(gesture)
    
    motion = Gtk.EventControllerMotion()
    motion.connect("enter", lambda c, x, y: box.set_cursor(Gdk.Cursor.new_from_name("pointer", None)))
    motion.connect("leave", lambda c: box.set_cursor(None))
    box.add_controller(motion)

    return box

# --- ЛОГІКА ---

def get_images():
    """Кешує список картинок для швидкого доступу"""
    global images_cache
    
    if images_cache:  # Повертаємо з кешу
        return images_cache
    
    if not os.path.exists(WALLPAPER_DIR):
        return []
    
    valid_extensions = ('.png', '.jpg', '.jpeg', '.webp')
    images_cache = sorted([
        os.path.join(WALLPAPER_DIR, f)
        for f in os.listdir(WALLPAPER_DIR)
        if f.lower().endswith(valid_extensions)
    ])
    
    return images_cache

def get_thumbnail_path(original_path):
    """Повертає шлях до мініатюри (без генерації)"""
    filename_hash = hashlib.md5(original_path.encode()).hexdigest()
    return os.path.join(CACHE_DIR, f"{filename_hash}.png")

def generate_thumbnail(original_path):
    """Генерує мініатюру якщо її немає"""
    thumb_path = get_thumbnail_path(original_path)
    
    if thumb_path in thumbnail_cache:
        return thumbnail_cache[thumb_path]
    
    try:
        if not os.path.exists(thumb_path):
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                original_path, THUMB_SIZE, -1, True
            )
            pixbuf.savev(thumb_path, "png", [], [])
        
        thumbnail_cache[thumb_path] = thumb_path
        return thumb_path
    except Exception as e:
        print(f"Помилка генерації мініатюри: {e}")
        return original_path

def create_card_widget(img_path, thumb_path):
    """Створює віджет картки шпалери"""
    filename = os.path.basename(img_path)
    safe_thumb_path = urllib.parse.quote(thumb_path)
    
    card_content = widgets.Box(
        vertical=True,
        child=[
            widgets.Box(hexpand=True, vexpand=True),
            widgets.Box(
                css_classes=["wp-label-box"],
                child=[widgets.Label(
                    label=filename,
                    css_classes=["wp-label"],
                    ellipsize="end",
                    max_width_chars=18
                )]
            )
        ]
    )

    btn = ClickableBox(
        child=card_content,
        on_click=lambda x, p=img_path: set_wallpaper(p),
        css_classes=["wp-card"]
    )
    
    btn.set_style(
        f"background-image: url('file://{safe_thumb_path}'); "
        f"background-size: cover; background-position: center;"
    )
    
    return btn

def add_card_to_grid(img_path, thumb_path):
    """Додає картку в FlowBox через GLib.idle_add (безпечно для GTK)"""
    def _add():
        if wp_flowbox:
            card = create_card_widget(img_path, thumb_path)
            wp_flowbox.append(card)
        return False
    
    GLib.idle_add(_add)

def populate_grid():
    """Швидко заповнює сітку з асинхронною генерацією мініатюр"""
    # Очищення
    while wp_flowbox.get_child_at_index(0):
        wp_flowbox.remove(wp_flowbox.get_child_at_index(0))

    images = get_images()
    
    if not images:
        lbl = widgets.Label(label="Немає картинок", css_classes=["wp-error"])
        wp_flowbox.append(lbl)
        return

    # Спочатку додаємо всі картки з готовими мініатюрами
    ready_images = []
    pending_images = []
    
    for img_path in images:
        thumb_path = get_thumbnail_path(img_path)
        if os.path.exists(thumb_path):
            ready_images.append((img_path, thumb_path))
        else:
            pending_images.append(img_path)
    
    # Миттєво показуємо готові мініатюри
    for img_path, thumb_path in ready_images:
        card = create_card_widget(img_path, thumb_path)
        wp_flowbox.append(card)
    
    # Генеруємо нові мініатюри в фоні
    if pending_images:
        def generate_thumbnails_async():
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = {
                    executor.submit(generate_thumbnail, img): img
                    for img in pending_images
                }
                
                for future in futures:
                    try:
                        thumb_path = future.result()
                        img_path = futures[future]
                        add_card_to_grid(img_path, thumb_path)
                    except Exception as e:
                        print(f"Помилка: {e}")
        
        thread = threading.Thread(target=generate_thumbnails_async, daemon=True)
        thread.start()

def set_wallpaper(path):
    """Встановлює шпалери"""
    cmd = f"swww img '{path}' --transition-type grow --transition-fps 60 --transition-duration 2"
    subprocess.Popen(cmd, shell=True)
    if wp_window:
        wp_window.visible = False

def on_toggle(action, param):
    """Перемикає видимість вікна"""
    if wp_window:
        if wp_window.visible:
            wp_window.visible = False
        else:
            populate_grid()
            wp_window.visible = True

def setup(app_instance):
    """Ініціалізує вікно та елементи інтерфейсу"""
    global wp_window, wp_flowbox
    
    # Передгенеруємо кеш при запуску в фоні
    def preload_cache():
        images = get_images()
        for img in images:
            generate_thumbnail(img)
    
    thread = threading.Thread(target=preload_cache, daemon=True)
    thread.start()
    
    wp_flowbox = Gtk.FlowBox()
    wp_flowbox.set_valign(Gtk.Align.START)
    wp_flowbox.set_max_children_per_line(30)
    wp_flowbox.set_min_children_per_line(1)
    wp_flowbox.set_selection_mode(Gtk.SelectionMode.NONE)
    wp_flowbox.set_column_spacing(20)
    wp_flowbox.set_row_spacing(20)

    scroll = widgets.Scroll(
        vexpand=True, 
        hexpand=True,
        child=wp_flowbox,
        css_classes=["wp-scroll"]
    )

    close_btn = ClickableBox(
        child=widgets.Label(label="Закрити", css_classes=["wp-close-label"]),
        on_click=lambda x: on_toggle(None, None),
        css_classes=["wp-close-btn"]
    )

    wp_window = widgets.Window(
        name="wallpaper_selector",
        namespace="ignis_wallpapers",
        anchor=[], 
        width_request=950,
        height_request=700,
        exclusivity="ignore",
        layer="overlay",
        visible=False,
        kb_mode="on_demand",
        css_classes=["wp-window"],
        child=widgets.Box(
            vertical=True,
            css_classes=["wp-container"],
            child=[
                widgets.Box(
                    spacing=10,
                    child=[
                        widgets.Label(
                            label="Галерея шпалер",
                            css_classes=["wp-title"],
                            halign="start",
                            hexpand=True
                        ),
                        close_btn
                    ]
                ),
                scroll
            ]
        )
    )

    # Обробка клавіші Esc
    key_controller = Gtk.EventControllerKey()
    
    def on_key_pressed(controller, keyval, keycode, state):
        if keyval == Gdk.KEY_Escape:
            on_toggle(None, None)
            return True
        return False

    key_controller.connect("key-pressed", on_key_pressed)
    wp_window.add_controller(key_controller)
    
    app_instance.add_window(window=wp_window, window_name="wallpaper_selector")

    action = Gio.SimpleAction.new("toggle-wallpapers", None)
    action.connect("activate", on_toggle)
    app_instance.add_action(action)