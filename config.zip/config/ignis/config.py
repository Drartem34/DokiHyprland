import sys
import os
import json
import subprocess
import asyncio
import gi
import urllib.parse

# --- ШЛЯХИ ---
sys.path.append(os.path.expanduser("~/.config/ignis"))

# --- ІМПОРТИ ---
import wallpapers
import switcher
import dock
import clipboard
import mixer
import launcher

# [1] ДОДАНО: Імпорт твого файлу меню (без папок)
try:
    import powermenu
except ImportError:
    print("Error: powermenu.py not found in config folder!")

gi.require_version('Gtk', '4.0')
from gi.repository import Gtk, Gdk
from ignis import widgets, utils
from ignis.app import IgnisApp
from ignis.services.audio import AudioService
from ignis.services.mpris import MprisService
from ignis.services.backlight import BacklightService

# Ініціалізація
app = IgnisApp.get_default()
audio = AudioService.get_default()
mpris = MprisService.get_default()
backlight = BacklightService.get_default()

# Стилі
try:
    app.apply_css(os.path.expanduser("~/.config/ignis/style.css"))
except Exception:
    pass


# --- ДОПОМІЖНІ ФУНКЦІЇ ---
def run_cmd(cmd):
    try:
        # LC_ALL=C змушує команду видавати результат англійською
        return subprocess.check_output(f"LC_ALL=C {cmd}", shell=True).decode("utf-8").strip()
    except:
        return ""

def run_async(cmd):
    subprocess.Popen(cmd, shell=True)

def get_wifi_status():
    ssid = run_cmd("nmcli -t -f TYPE,NAME connection show --active | grep '802-11-wireless' | cut -d: -f2 | head -n 1")
    state = run_cmd("nmcli -t -f STATE general")
    return ssid, "connected" in state

def get_bt_status():
    out = run_cmd("bluetoothctl show | grep 'Powered: yes'")
    return bool(out)

# --- CUSTOM CLICKABLE BOX ---
def ClickableBox(child, on_click, css_classes=[], spacing=0, centered=False, **kwargs):
    if centered and child:
        child.set_halign("center")
        child.set_valign("center")
        child.set_hexpand(True)
        child.set_vexpand(True)
    
    classes = css_classes + ["unset", "clickable-box"]

    box = widgets.Box(
        child=[child] if child else [],
        css_classes=classes,
        spacing=spacing,
        **kwargs
    )
    
    gesture = Gtk.GestureClick()
    gesture.connect("released", lambda x, n, a, b: on_click(box))
    box.add_controller(gesture)
    
    def on_hover(controller, x, y):
        try: box.set_cursor(Gdk.Cursor.new_from_name("pointer", None))
        except: pass
    
    def on_unhover(controller):
        try: box.set_cursor(None)
        except: pass
    
    motion = Gtk.EventControllerMotion()
    motion.connect("enter", on_hover)
    motion.connect("leave", on_unhover)
    box.add_controller(motion)

    return box

# --- WI-FI WIDGET ---
def WifiWidget():
    list_revealer = widgets.Revealer(transition_type="slide_down")
    list_box = widgets.Box(vertical=True, spacing=5, css_classes=["list-container"])
    
    icon_widget = widgets.Icon(image="network-wireless-symbolic", pixel_size=24, css_classes=["b-icon"])
    status_label = widgets.Label(label="Перевірка...", halign="start", css_classes=["card-status"], ellipsize="end")

    def get_ethernet_status():
        """Перевіряє підключення по дроту"""
        try:
            eth_active = run_cmd("nmcli -t -f TYPE,NAME connection show --active | grep 'ethernet' | cut -d: -f2 | head -n 1")
            return eth_active.strip() if eth_active else None
        except:
            return None

    def create_wifi_row(ssid, is_active, strength, is_saved):
        entry = widgets.Entry(
            placeholder_text="Введіть пароль...", 
            css_classes=["wifi-password-entry"], 
            hexpand=True
        )
        entry.set_visibility(False)
        
        btn_label = widgets.Label(label="Підключити", style="font-weight: bold; color: #1e1e2e;")
        btn_connect = ClickableBox(
            child=btn_label,
            css_classes=["wifi-connect-btn"],
            on_click=lambda x: connect_to_network(ssid, entry.get_text()),
            centered=True
        )
        
        btn_forget = None
        if is_saved:
            forget_label = widgets.Label(label="Забути", style="font-weight: bold; color: #f38ba8;")
            btn_forget = ClickableBox(
                child=forget_label,
                css_classes=["wifi-connect-btn"],
                on_click=lambda x: forget_network(ssid),
                centered=True
            )
        
        password_area = widgets.Box(spacing=5, child=[entry, btn_connect])
        pass_revealer = widgets.Revealer(
            transition_type="slide_down", 
            child=password_area, 
            reveal_child=False
        )
        
        forget_area = widgets.Box(spacing=5, child=[btn_forget] if btn_forget else [])
        forget_revealer = widgets.Revealer(
            transition_type="slide_down",
            child=forget_area,
            reveal_child=False
        )

        def connect_to_network(ssid, password):
            if password:
                run_async(f"nmcli dev wifi connect '{ssid}' password '{password}'")
                pass_revealer.set_reveal_child(False)
                utils.Timeout(1500, refresh_wifi_list)

        def forget_network(ssid):
            run_async(f"nmcli connection delete id '{ssid}'")
            forget_revealer.set_reveal_child(False)
            utils.Timeout(1000, refresh_wifi_list)

        def on_click_network(x):
            if is_active:
                run_async(f"nmcli connection down id '{ssid}'")
                utils.Timeout(1000, refresh_wifi_list)
            elif is_saved:
                run_async(f"nmcli connection up id '{ssid}'")
                utils.Timeout(1500, refresh_wifi_list)
            else:
                is_open = pass_revealer.get_reveal_child()
                pass_revealer.set_reveal_child(not is_open)

        def on_right_click(gesture, n_press, x, y):
            if gesture.get_current_button() == 3 and is_saved:
                is_open = forget_revealer.get_reveal_child()
                forget_revealer.set_reveal_child(not is_open)

        if strength >= 75:
            signal_icon = "network-wireless-signal-excellent-symbolic"
        elif strength >= 50:
            signal_icon = "network-wireless-signal-good-symbolic"
        elif strength >= 25:
            signal_icon = "network-wireless-signal-ok-symbolic"
        else:
            signal_icon = "network-wireless-signal-weak-symbolic"

        row_content = widgets.Box(spacing=10, child=[
            widgets.Icon(image=signal_icon, pixel_size=20, css_classes=["list-icon"]),
            widgets.Label(
                label=f"{ssid} ({strength}%)" + (" 🔒" if is_saved else ""), 
                css_classes=["list-label"], 
                ellipsize="end", 
                halign="start", 
                hexpand=True
            ),
            widgets.Icon(
                image="object-select-symbolic" if is_active else "", 
                pixel_size=16, 
                css_classes=["list-status"]
            )
        ])

        clickable_row = ClickableBox(child=row_content, on_click=on_click_network, hexpand=True)
        
        if is_saved:
            right_click = Gtk.GestureClick()
            right_click.set_button(3)
            right_click.connect("released", on_right_click)
            clickable_row.add_controller(right_click)

        item_box = widgets.Box(vertical=True, css_classes=["list-item"], child=[
            clickable_row,
            pass_revealer,
            forget_revealer
        ])
        
        if is_active:
            item_box.add_css_class("list-item-active")
            
        return item_box

    def refresh_wifi_list():
        child = list_box.get_first_child()
        while child:
            list_box.remove(child)
            child = list_box.get_first_child()
            
        list_box.append(widgets.Label(label="Сканування...", css_classes=["b-subtext"]))
        
        def scan_process():
            try:
                run_cmd("nmcli dev wifi rescan 2>/dev/null || true")
                utils.Timeout(500, lambda: populate_list())
            except:
                child = list_box.get_first_child()
                while child:
                    list_box.remove(child)
                    child = list_box.get_first_child()
                list_box.append(widgets.Label(label="Помилка сканування", css_classes=["b-subtext"]))
        
        def populate_list():
            try:
                raw = run_cmd("nmcli -t -f SSID,IN-USE,SIGNAL,SECURITY dev wifi list")
                
                saved_networks = set()
                try:
                    saved = run_cmd("nmcli -t -f NAME connection show")
                    saved_networks = set(saved.split('\n')) if saved else set()
                except:
                    pass
                
                child = list_box.get_first_child()
                while child:
                    list_box.remove(child)
                    child = list_box.get_first_child()
                
                if not raw:
                    list_box.append(widgets.Label(label="Немає мереж", css_classes=["b-subtext"]))
                    return
                
                lines = raw.split('\n')
                unique_ssids = set()
                count = 0
                
                for line in lines:
                    if not line or count >= 20:
                        continue
                        
                    parts = line.split(':')
                    if len(parts) < 3:
                        continue
                        
                    ssid = parts[0].strip()
                    is_active = (parts[1] == "*")
                    
                    try:
                        strength = int(parts[2])
                    except:
                        strength = 0
                    
                    if not ssid or ssid in unique_ssids:
                        continue
                        
                    unique_ssids.add(ssid)
                    is_saved = ssid in saved_networks
                    
                    list_box.append(create_wifi_row(ssid, is_active, strength, is_saved))
                    count += 1
                
                if count == 0:
                    list_box.append(widgets.Label(label="Немає доступних мереж", css_classes=["b-subtext"]))
                    
            except Exception as e:
                child = list_box.get_first_child()
                while child:
                    list_box.remove(child)
                    child = list_box.get_first_child()
                list_box.append(widgets.Label(label=f"Помилка: {str(e)}", css_classes=["b-subtext"]))
        
        utils.Timeout(100, scan_process)

    def toggle_list(widget):
        is_open = list_revealer.get_reveal_child()
        if not is_open:
            refresh_wifi_list()
        list_revealer.set_reveal_child(not is_open)

    def poll_status(widget):
        ssid = run_cmd("nmcli -t -f TYPE,NAME connection show --active | grep '802-11-wireless' | cut -d: -f2 | head -n 1")
        eth_name = get_ethernet_status()
        
        if ssid:
            status_label.set_label(ssid.strip())
            icon_widget.set_image("network-wireless-connected-symbolic")
            icon_widget.remove_css_class("dim-icon")
            icon_widget.add_css_class("accent-icon")
        elif eth_name:
            status_label.set_label(f"Ethernet: {eth_name.strip()}")
            icon_widget.set_image("network-wired-symbolic")
            icon_widget.remove_css_class("dim-icon")
            icon_widget.add_css_class("accent-icon")
        else:
            radio = run_cmd("nmcli radio wifi")
            if radio == "disabled":
                status_label.set_label("Вимкнено")
                icon_widget.set_image("network-wireless-disabled-symbolic")
            else:
                status_label.set_label("Не підключено")
                icon_widget.set_image("network-wireless-offline-symbolic")
            icon_widget.remove_css_class("accent-icon")
            icon_widget.add_css_class("dim-icon")
    
    utils.Poll(3000, lambda x: poll_status(None))
    poll_status(None)

    power_btn = ClickableBox(
        child=widgets.Icon(image="system-shutdown-symbolic", pixel_size=20), 
        css_classes=["power-btn"],
        on_click=lambda x: toggle_wifi_power(),
        centered=True
    )
    
    def toggle_wifi_power():
        current = run_cmd("nmcli radio wifi")
        if current == "enabled":
            run_async("nmcli radio wifi off")
        else:
            run_async("nmcli radio wifi on")
        utils.Timeout(500, lambda: poll_status(None))
    
    header_left = ClickableBox(
        child=widgets.Box(spacing=12, child=[
            icon_widget, 
            widgets.Box(vertical=True, valign="center", child=[
                widgets.Label(label="Wi-Fi / Мережа", halign="start", css_classes=["card-title"]), 
                status_label
            ])
        ]),
        on_click=toggle_list,
        css_classes=["header-left"],
        hexpand=True
    )
    
    header = widgets.Box(spacing=0, child=[
        header_left,
        widgets.Box(hexpand=True),
        power_btn
    ])
    
    scroll = widgets.Scroll(height_request=300, child=list_box)
    list_revealer.set_child(scroll)
    
    return widgets.Box(
        vertical=True,
        css_classes=["block", "dark", "wide"],
        child=[
            widgets.Box(css_classes=["header-padding"], child=[header]),
            list_revealer
        ]
    )

# --- BLUETOOTH WIDGET ---
bt_scan_process = None

def BluetoothWidget():
    list_revealer = widgets.Revealer(transition_type="slide_down")
    list_box = widgets.Box(vertical=True, spacing=5, css_classes=["list-container"])
    
    icon_widget = widgets.Icon(image="bluetooth-active-symbolic", pixel_size=24, css_classes=["b-icon"])
    status_label = widgets.Label(label="Checking...", halign="start", css_classes=["card-status"])
    scan_btn_label = widgets.Label(label="Scan")

    def toggle_scan(btn_box):
        global bt_scan_process
        if bt_scan_process:
            run_async("bluetoothctl scan off")
            bt_scan_process = None
            scan_btn_label.set_label("Scan")
            btn_box.remove_css_class("active-scan-btn")
        else:
            run_async("bluetoothctl scan on")
            bt_scan_process = True
            scan_btn_label.set_label("Stop")
            btn_box.add_css_class("active-scan-btn")
            refresh_bt_list()

    def create_bt_row(mac, name, is_connected, is_paired):
        pair_label = widgets.Label(label="Pair & Connect", style="color: #1e1e2e; font-weight: bold;")
        pair_btn = ClickableBox(
            child=pair_label,
            css_classes=["wifi-connect-btn"],
            on_click=lambda x: run_async(f"bluetoothctl trust {mac} && bluetoothctl pair {mac} && bluetoothctl connect {mac}"),
            centered=True
        )
        action_revealer = widgets.Revealer(transition_type="slide_down", child=widgets.Box(child=[pair_btn]), reveal_child=False)

        def on_click_device(x):
            if is_connected:
                run_async(f"bluetoothctl disconnect {mac}")
            elif is_paired:
                run_async(f"bluetoothctl connect {mac}")
            else:
                action_revealer.set_reveal_child(not action_revealer.get_reveal_child())

        status_icon_name = "object-select-symbolic" if is_connected else ("network-wired-symbolic" if is_paired else "")
        
        row_content = widgets.Box(spacing=10, child=[
            widgets.Icon(image="bluetooth-symbolic", pixel_size=20, css_classes=["list-icon"]),
            widgets.Label(label=name if name else mac, css_classes=["list-label"], ellipsize="end", halign="start", hexpand=True),
            widgets.Icon(image=status_icon_name, pixel_size=16, css_classes=["list-status"])
        ])

        item_box = widgets.Box(vertical=True, css_classes=["list-item"], child=[
            ClickableBox(child=row_content, on_click=on_click_device, hexpand=True),
            action_revealer
        ])
        if is_connected: item_box.add_css_class("list-item-active")
        return item_box

    def refresh_bt_list():
        if not list_revealer.get_reveal_child(): return
        child = list_box.get_first_child()
        while child: list_box.remove(child); child = list_box.get_first_child()
        try:
            raw = run_cmd("bluetoothctl devices")
            lines = raw.split('\n'); count = 0
            for line in lines:
                if not line: continue
                parts = line.split(' ', 2)
                if len(parts) < 3: continue
                mac = parts[1]; name = parts[2]
                info = run_cmd(f"bluetoothctl info {mac}")
                is_connected = "Connected: yes" in info
                is_paired = "Paired: yes" in info
                list_box.append(create_bt_row(mac, name, is_connected, is_paired))
                count += 1
            if count == 0: 
                list_box.append(widgets.Label(label="No devices found", css_classes=["b-subtext"]))
                if not bt_scan_process:
                    list_box.append(widgets.Label(label="Press Scan to find new", css_classes=["b-subtext"]))
        except: list_box.append(widgets.Label(label="Error", css_classes=["b-subtext"]))
        
        if bt_scan_process:
            utils.Timeout(2000, refresh_bt_list)

    def toggle_list(widget):
        is_open = list_revealer.get_reveal_child()
        if not is_open: refresh_bt_list()
        list_revealer.set_reveal_child(not is_open)

    def poll_status(widget):
        is_on = get_bt_status()
        status_label.set_label("On" if is_on else "Off")
        icon_widget.set_image("bluetooth-active-symbolic" if is_on else "bluetooth-disabled-symbolic")
        if is_on: icon_widget.add_css_class("accent-icon"); icon_widget.remove_css_class("dim-icon")
        else: icon_widget.add_css_class("dim-icon"); icon_widget.remove_css_class("accent-icon")

    utils.Poll(2000, lambda x: poll_status(None))

    scan_btn = ClickableBox(
        child=scan_btn_label, css_classes=["wifi-connect-btn"],
        on_click=toggle_scan, centered=True
    )
    power_btn = ClickableBox(
        child=widgets.Icon(image="system-shutdown-symbolic", pixel_size=20), 
        css_classes=["power-btn"],
        on_click=lambda x: run_async("bluetoothctl power off" if get_bt_status() else "bluetoothctl power on"),
        centered=True
    )
    header_left = ClickableBox(
        child=widgets.Box(spacing=12, child=[
            icon_widget, 
            widgets.Box(vertical=True, valign="center", child=[
                widgets.Label(label="Bluetooth", halign="start", css_classes=["card-title"]), 
                status_label
            ])
        ]),
        on_click=toggle_list, css_classes=["header-left"],
        hexpand=True
    )
    header = widgets.Box(spacing=5, child=[header_left, widgets.Box(hexpand=True), scan_btn, power_btn])
    scroll = widgets.Scroll(height_request=250, child=list_box); list_revealer.set_child(scroll)
    return widgets.Box(vertical=True, css_classes=["block", "dark", "wide"], child=[widgets.Box(css_classes=["header-padding"], child=[header]), list_revealer])

# --- МЕДІА ВІДЖЕТ ---
def MediaWidget():
    players_box = widgets.Box(vertical=True, spacing=10)

    def get_art_css(url):
        if not url: return ""
        if not url.startswith("http") and not url.startswith("file"):
            url = "file://" + url
        return f"background-image: url('{url}'); background-size: cover; background-position: center;"

    def on_player_added(service, player):
        player_widget = widgets.Box(
            vertical=True,
            css_classes=["music-box"], 
            child=[
                widgets.Box(spacing=15, child=[
                    widgets.Box(
                        css_classes=["music-art-icon"],
                        style=player.bind("art_url", get_art_css),
                        child=[
                            widgets.Icon(image="folder-music-symbolic", visible=player.bind("art_url", lambda u: not u), pixel_size=32)
                        ]
                    ),
                    widgets.Box(vertical=True, valign="center", hexpand=True, child=[
                        widgets.Label(
                            label=player.bind("title"), 
                            halign="start", ellipsize="end", css_classes=["music-title"]
                        ),
                        widgets.Label(
                            label=player.bind("artist"), 
                            halign="start", ellipsize="end", css_classes=["music-artist"]
                        )
                    ])
                ]),
                widgets.Scale(
                    hexpand=True,
                    css_classes=["b-slider", "media-scale"],
                    min=0,
                    max=player.bind("length"),
                    value=player.bind("position"),
                    on_change=lambda x: player.set_position(x.value),
                    visible=player.bind("length", lambda l: l > 0)
                ),
                widgets.Box(height_request=5),
                widgets.Box(halign="center", spacing=20, child=[
                    ClickableBox(
                        child=widgets.Icon(image="media-skip-backward-symbolic", pixel_size=24), 
                        on_click=lambda x: player.previous(), 
                        css_classes=["control-btn"], centered=True
                    ),
                    ClickableBox(
                        child=widgets.Icon(
                            image=player.bind("playback_status", lambda s: "media-playback-pause-symbolic" if s == "Playing" else "media-playback-start-symbolic"),
                            pixel_size=32
                        ), 
                        on_click=lambda x: player.play_pause(), 
                        css_classes=["play-btn"], spacing=0, centered=True
                    ),
                    ClickableBox(
                        child=widgets.Icon(image="media-skip-forward-symbolic", pixel_size=24), 
                        on_click=lambda x: player.next(), 
                        css_classes=["control-btn"], centered=True
                    )
                ])
            ]
        )
        player.connect("closed", lambda x: players_box.remove(player_widget))
        players_box.append(player_widget)

    mpris.connect("player-added", on_player_added)
    for p in mpris.players:
        on_player_added(mpris, p)

    return widgets.Box(
        vertical=True, 
        child=[
            players_box,
            widgets.Box(
                visible=mpris.bind("players", lambda p: len(p) == 0),
                css_classes=["music-box"],
                child=[widgets.Label(label="No Media Playing", css_classes=["music-title"], halign="center")]
            )
        ]
    )

# --- VOLUME WIDGET ---
def VolumeSlider(stream_type):
    stream = getattr(audio, stream_type)
    
    icon_box = ClickableBox(
        child=widgets.Icon(image=stream.bind("icon_name"), pixel_size=20),
        css_classes=["b-icon-btn"], 
        on_click=lambda x: stream.set_is_muted(not stream.is_muted),
        centered=True
    )

    scale = widgets.Scale(
        min=0, max=100, step=1, hexpand=True, 
        css_classes=["b-slider"],
        value=stream.bind("volume"),
        on_change=lambda x: stream.set_volume(x.value)
    )

    return widgets.Box(
        css_classes=["block", "dark", "wide"], 
        spacing=10, 
        child=[icon_box, scale]
    )

# --- BRIGHTNESS WIDGET ---
def BrightnessSlider():
    return widgets.Box(
        visible=backlight.bind("available"),
        css_classes=["block", "dark", "wide"], 
        spacing=10, 
        child=[
            widgets.Icon(image="display-brightness-symbolic", pixel_size=20, css_classes=["b-icon"]),
            widgets.Scale(
                min=0, max=backlight.max_brightness, hexpand=True,
                css_classes=["b-slider"],
                value=backlight.bind("brightness"),
                on_change=lambda x: backlight.set_brightness(x.value)
            )
        ]
    )

# --- СПОВІЩЕННЯ ---
# --- ПОКРАЩЕНИЙ БЛОК СПОВІЩЕНЬ (SMART TIME) ---
HIDDEN_NOTIF_IDS = set()
PINNED_NOTIF_IDS = set()

# --- ВАШ ВАЙТЛІСТ (TOP_CONTACTS) ---
TOP_CONTACTS = ["MOM", "Тато", "Тривога", "Банк", "Boss", "Оплата"]

# Фільтр спаму
BLACKLIST = ["notify-send", "volume", "brightness", "backlight", "microphone", "battery"]

def NotificationItem(appname, summary, body, icon_data, item_id, on_dismiss, on_pin, on_refresh, is_pinned=False):
    """Створює елемент сповіщення"""
    
    def get_val(key):
        val = icon_data.get(key)
        if isinstance(val, dict): return val.get("data", "")
        return val if val else ""
    
    # 1. ПЕРЕВІРКА ВАЙТЛІСТА (Золота рамка)
    full_text = (str(summary) + " " + str(body) + " " + str(appname)).lower()
    is_top = any(contact.lower() in full_text for contact in TOP_CONTACTS)
    item_style = "border: 2px solid #ffd700; background-color: rgba(60, 56, 54, 0.95);" if is_top else ""

    # Іконка
    raw_path = get_val("icon_path")
    raw_name = get_val("app_icon")
    image_source = "dialog-information"
    
    if raw_path and "/" in raw_path:
        clean_path = raw_path.replace("file://", "")
        if os.path.exists(clean_path): image_source = clean_path
    elif raw_name: image_source = raw_name
    elif appname: image_source = appname.lower().split()[0]
    
    icon_mapping = {"telegram": "telegram", "code": "code", "firefox": "firefox", "chrome": "google-chrome", "discord": "discord", "spotify": "spotify", "viber": "viber"}
    for key, icon in icon_mapping.items():
        if key in image_source.lower():
            image_source = icon
            break
            
    # 2. РОЗУМНИЙ ЧАС (SMART TIME)
    timestamp = get_val("timestamp")
    time_label = ""
    if timestamp:
        try:
            import time
            import datetime
            
            ts_int = int(timestamp)
            # Авто-визначення: якщо число величезне -> це мікросекунди, якщо менше -> секунди
            if ts_int > 10000000000000: ts_seconds = ts_int // 1000000
            else: ts_seconds = ts_int
            
            now = int(time.time())
            diff = now - ts_seconds
            
            # Логіка відображення
            if diff < 0: diff = 0
            
            if diff < 60:
                time_label = "щойно"
            elif diff < 3600:
                time_label = f"{diff // 60}хв"
            elif diff < 86400: # Менше 24 годин
                # Перевіряємо чи це сьогодні
                dt = datetime.datetime.fromtimestamp(ts_seconds)
                now_dt = datetime.datetime.now()
                if dt.date() == now_dt.date():
                    time_label = dt.strftime("%H:%M") # Сьогодні -> 20:30
                else:
                    time_label = dt.strftime("%d.%m") # Вчора -> 15.05
            else:
                dt = datetime.datetime.fromtimestamp(ts_seconds)
                time_label = dt.strftime("%d.%m") # Старе -> 15.05
        except: 
            time_label = ""
    
    # Кнопки
    actions_box = widgets.Box(spacing=6, css_classes=["notif-actions"])
    
    pin_btn = ClickableBox(
        child=widgets.Icon(image="pin-symbolic" if not is_pinned else "starred-symbolic", pixel_size=16),
        css_classes=["notif-action-btn", "pin-btn"] + (["active"] if is_pinned else []),
        on_click=lambda x: [on_pin(item_id), utils.Timeout(100, on_refresh)], centered=True
    )
    
    dismiss_btn = ClickableBox(
        child=widgets.Icon(image="user-trash-symbolic", pixel_size=16),
        css_classes=["notif-action-btn", "dismiss-btn"],
        on_click=lambda x: on_dismiss(box, item_id), centered=True
    )
    
    def copy_text():
        try: subprocess.run(["wl-copy", f"{summary}\n{body}"], check=False)
        except: pass
    
    copy_btn = ClickableBox(
        child=widgets.Icon(image="edit-copy-symbolic", pixel_size=16),
        css_classes=["notif-action-btn", "copy-btn"],
        on_click=lambda x: copy_text(), centered=True
    )
    
    actions_box.child = [pin_btn, copy_btn, dismiss_btn]
    
    # Контент
    content_box = widgets.Box(vertical=True, hexpand=True, child=[
        widgets.Box(spacing=8, child=[
            widgets.Icon(image=image_source, pixel_size=32, css_classes=["notif-icon-img"]),
            widgets.Box(vertical=True, valign="center", hexpand=True, child=[
                widgets.Label(label=appname or "Система", css_classes=["notif-appname"], halign="start", ellipsize="end", style="color: #ffd700; font-weight: bold;" if is_top else ""),
                widgets.Label(label=summary or "Сповіщення", css_classes=["notif-summary"], halign="start", ellipsize="end", max_width_chars=35)
            ]),
            widgets.Label(label=time_label, css_classes=["notif-time"], halign="end", valign="start")
        ]),
        widgets.Box(height_request=6),
        widgets.Label(label=body or "", css_classes=["notif-body"], halign="start", wrap=True, max_width_chars=50, visible=bool(body)),
        widgets.Box(height_request=6),
        actions_box
    ])
    
    box = widgets.Box(css_classes=["notif-item"] + (["pinned"] if is_pinned else []), style=item_style, child=[
        widgets.Box(css_classes=["pin-indicator"], visible=is_pinned, width_request=4, style="background-color: #ffd700;" if is_top else ""),
        content_box
    ])
    
    # Кліки
    expanded = [False]
    def on_click_handler(gesture, n_press, x, y):
        b = gesture.get_current_button()
        if b == 1: expanded[0] = not expanded[0]; actions_box.set_visible(expanded[0])
        elif b == 2: on_dismiss(box, item_id)
        elif b == 3: on_pin(item_id); utils.Timeout(100, on_refresh)
    
    gesture = Gtk.GestureClick()
    gesture.set_button(0)
    gesture.connect("released", on_click_handler)
    box.add_controller(gesture)
    
    return box

def NotificationWidget():
    """Головний віджет сповіщень"""
    notif_list = widgets.Box(vertical=True, spacing=8)
    pinned_list = widgets.Box(vertical=True, spacing=8)
    stats_label = widgets.Label(label="0 сповіщень", css_classes=["notif-stats"], halign="start")
    
    def dismiss_item(widget, notif_id):
        try: notif_list.remove(widget)
        except: pass
        try: pinned_list.remove(widget)
        except: pass
        if notif_id:
            HIDDEN_NOTIF_IDS.add(notif_id)
            if notif_id in PINNED_NOTIF_IDS: PINNED_NOTIF_IDS.remove(notif_id)
        utils.Timeout(50, refresh_notifications)
    
    def toggle_pin(notif_id):
        if notif_id in PINNED_NOTIF_IDS: PINNED_NOTIF_IDS.remove(notif_id)
        else: PINNED_NOTIF_IDS.add(notif_id)
    
    def refresh_notifications():
        child = notif_list.get_first_child()
        while child: notif_list.remove(child); child = notif_list.get_first_child()
        child = pinned_list.get_first_child()
        while child: pinned_list.remove(child); child = pinned_list.get_first_child()
        
        try:
            raw_json = run_cmd("dunstctl history")
            if not raw_json:
                notif_list.append(widgets.Label(label="📭 Немає історії", css_classes=["b-subtext"]))
                stats_label.set_label("0")
                return
            
            data = json.loads(raw_json)
            history = data.get("data", [[]])[0]
            count = 0
            pinned_count = 0
            
            for item in history:
                if count >= 50: break
                item_id = item.get("id", {}).get("data")
                if item_id in HIDDEN_NOTIF_IDS: continue
                
                appname = item.get("appname", {}).get("data", "Система")
                summary = item.get("summary", {}).get("data", "")
                body = item.get("body", {}).get("data", "")
                
                # Спам фільтр
                check_str = (appname + " " + summary + " " + body).lower()
                is_spam = any(bad_word in check_str for bad_word in BLACKLIST)
                if is_spam: continue
                
                is_pinned = item_id in PINNED_NOTIF_IDS
                ni = NotificationItem(appname, summary, body, item, item_id, dismiss_item, toggle_pin, refresh_notifications, is_pinned)
                
                if is_pinned: pinned_list.append(ni); pinned_count += 1
                else: notif_list.append(ni)
                count += 1
            
            if count == 0: notif_list.append(widgets.Label(label="🎉 Пусто", css_classes=["b-subtext"]))
            stats_label.set_label(f"{count} шт." + (f" • {pinned_count} 📌" if pinned_count else ""))
            pinned_section.set_visible(pinned_count > 0)
            
        except: pass
    
    utils.Poll(3000, lambda x: refresh_notifications())
    
    def clear_all():
        child = notif_list.get_first_child()
        while child: notif_list.remove(child); child = notif_list.get_first_child()
        HIDDEN_NOTIF_IDS.clear(); PINNED_NOTIF_IDS.clear()
        stats_label.set_label("Очищення...")
        run_async("dunstctl close-all")
        run_async("dunstctl history-clear") 
        utils.Timeout(500, refresh_notifications)

    pinned_section = widgets.Box(vertical=True, css_classes=["pinned-section"], visible=False, child=[
        widgets.Label(label="📌 Закріплені", css_classes=["section-header"], halign="start"),
        widgets.Box(height_request=6), pinned_list, widgets.Box(height_request=12)
    ])
    
    refresh_notifications()
    
    return widgets.Box(vertical=True, css_classes=["dunst-block"], vexpand=True, child=[
        widgets.Box(child=[
            widgets.Label(label="Сповіщення", css_classes=["dunst-header"]), widgets.Box(hexpand=True), stats_label
        ]),
        widgets.Box(height_request=10),
        widgets.Box(spacing=8, css_classes=["notif-controls"], child=[
             ClickableBox(child=widgets.Box(spacing=6, child=[widgets.Icon(image="edit-clear-symbolic", pixel_size=16), widgets.Label(label="Прочитані")]), css_classes=["notif-control-btn"], on_click=lambda x: [run_async("dunstctl close-all"), utils.Timeout(200, refresh_notifications)]),
             ClickableBox(child=widgets.Box(spacing=6, child=[widgets.Icon(image="notifications-disabled-symbolic", pixel_size=16), widgets.Label(label="Тиша")]), css_classes=["notif-control-btn"], on_click=lambda x: run_async("dunstctl set-paused toggle")),
             ClickableBox(child=widgets.Box(spacing=6, child=[widgets.Icon(image="user-trash-full-symbolic", pixel_size=16), widgets.Label(label="Все")]), css_classes=["notif-control-btn", "clear-all"], on_click=lambda x: clear_all())
        ]),
        widgets.Box(height_request=10),
        widgets.Scroll(vexpand=True, child=widgets.Box(vertical=True, child=[pinned_section, notif_list]))
    ])

# --- НОВИЙ ВІДЖЕТ МОНІТОРИНГУ СИСТЕМИ ---
def SystemStatsWidget():
    # Елементи UI
    cpu_label = widgets.Label(label="CPU", css_classes=["sys-label"], halign="start")
    cpu_value = widgets.Label(label="0% | 0°C", css_classes=["sys-value"], halign="end", hexpand=True)
    cpu_bar = widgets.Scale(min=0, max=100, css_classes=["sys-bar"], hexpand=True)
    cpu_bar.set_sensitive(False)

    gpu_label = widgets.Label(label="GPU", css_classes=["sys-label"], halign="start")
    gpu_value = widgets.Label(label="0% | 0°C", css_classes=["sys-value"], halign="end", hexpand=True)
    gpu_bar = widgets.Scale(min=0, max=100, css_classes=["sys-bar"], hexpand=True)
    gpu_bar.set_sensitive(False)

    ram_label = widgets.Label(label="RAM", css_classes=["sys-label"], halign="start")
    ram_value = widgets.Label(label="0/0 GB", css_classes=["sys-value"], halign="end", hexpand=True)
    ram_bar = widgets.Scale(min=0, max=100, css_classes=["sys-bar"], hexpand=True)
    ram_bar.set_sensitive(False)

    def update_stats(widget):
        try:
            # CPU
            cpu_usage_cmd = "top -bn1 | grep 'Cpu(s)' | sed 's/.*, *\\([0-9.]*\\)%* id.*/\\1/' | awk '{print 100 - $1}'"
            cpu_usage = float(run_cmd(cpu_usage_cmd) or 0)
            try:
                with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
                    cpu_temp = int(f.read().strip()) // 1000
            except: cpu_temp = 0
            cpu_value.set_label(f"{int(cpu_usage)}% | {cpu_temp}°C")
            cpu_bar.set_value(cpu_usage)

            # GPU
            try:
                gpu_info = run_cmd("nvidia-smi --query-gpu=utilization.gpu,temperature.gpu --format=csv,noheader,nounits")
                if gpu_info:
                    g_util, g_temp = gpu_info.split(',')
                    gpu_value.set_label(f"{int(g_util)}% | {int(g_temp)}°C")
                    gpu_bar.set_value(int(g_util))
            except: gpu_value.set_label("N/A")

            # RAM
            ram_info = run_cmd("free -m | awk 'NR==2{print $2,$3}'")
            if ram_info:
                total, used = map(int, ram_info.split())
                percent = (used / total) * 100
                ram_value.set_label(f"{round(used/1024, 1)}/{round(total/1024, 1)} GB")
                ram_bar.set_value(percent)
        except: pass

    utils.Poll(2000, lambda x: update_stats(None))

    def create_row(icon, label, value, bar):
        return widgets.Box(vertical=True, spacing=2, child=[
            widgets.Box(spacing=10, child=[
                widgets.Icon(image=icon, pixel_size=16, css_classes=["sys-icon"]),
                label, value
            ]), bar
        ])

    return widgets.Box(vertical=True, css_classes=["block", "dark", "wide"], spacing=10, child=[
        create_row("cpu-symbolic", cpu_label, cpu_value, cpu_bar),
        create_row("video-display-symbolic", gpu_label, gpu_value, gpu_bar),
        create_row("memory-symbolic", ram_label, ram_value, ram_bar)
    ])

def HeaderWidget():
    """Заголовок з кнопками переходу"""
    power_btn = ClickableBox(
        child=widgets.Icon(image="system-shutdown-symbolic", pixel_size=20, style="color: #181825;"), 
        on_click=lambda x: app.get_window("powermenu").set_visible(True), 
        style="background-color: #f38ba8; border-radius: 12px; padding: 2px; min-width: 5px; min-height: 5px;",
        centered=True
    )
    
    # Кнопка переходу на сторінку 2
    def go_to_page2(x):
        window = app.get_window("control_center")
        if hasattr(window, '_switch_page'):
            window._switch_page(1)
    
    settings_btn = ClickableBox(
        child=widgets.Icon(image="system-run-symbolic", pixel_size=20, style="color: #181825;"),
        on_click=go_to_page2,
        style="background-color: #89b4fa; border-radius: 12px; padding: 2px; min-width: 5px; min-height: 5px; margin-right: 8px;",
        centered=True
    )
    
    return widgets.Box(
        style="margin-bottom: 5px;",
        child=[
            widgets.Label(
                label="Швидкий доступ",
                css_classes=["card-title"], 
                style="font-size: 18px; font-weight: bold;", 
                halign="start", 
                hexpand=True
            ),
            settings_btn,
            power_btn
        ]
    )

# --- MAIN CONTROL CENTER ---
def create_control_center():
    """Створює дво-сторінкове вікно Control Center"""
    
    # Контейнер для сторінок
    pages_stack = widgets.Box(vertical=True, css_classes=["main-bg"], vexpand=True)
    
    # --- СТОРІНКА 1: ОСНОВНА ---
    # ДОДАНО: vexpand=True, щоб контент міг розтягуватися і штовхати NotificationWidget
    page1_content = widgets.Box(vertical=True, vexpand=True, child=[
        HeaderWidget(),
        widgets.Box(height_request=10),
        widgets.Box(spacing=10, child=[WifiWidget(), BluetoothWidget()]),
        widgets.Box(height_request=15), 
        MediaWidget(),
        widgets.Box(height_request=15),
        VolumeSlider("speaker"),
        widgets.Box(height_request=10), 
        VolumeSlider("microphone"),
        widgets.Box(height_request=10),
        BrightnessSlider(),
        widgets.Box(height_request=15), 
        NotificationWidget()
    ])
    
    # --- СТОРІНКА 2: СИСТЕМА ТА АУДІО ---
    page2_header = widgets.Box(
        style="margin-bottom: 5px;",
        child=[
            widgets.Label(
                label="Система та Аудіо",
                css_classes=["card-title"], 
                style="font-size: 18px; font-weight: bold;", 
                halign="start", 
                hexpand=True
            )
        ]
    )
    
    page2_content = widgets.Box(vertical=True, child=[
        page2_header,
        widgets.Box(height_request=10),
        SystemStatsWidget(),
        widgets.Box(height_request=15),
        mixer.MixerWidget(),
        widgets.Box(height_request=15),
        widgets.Box(vertical=True, css_classes=["block", "dark", "wide"], child=[
            widgets.Label(label="Аудіо пристрої", css_classes=["card-title"], halign="start"),
            widgets.Box(height_request=10),
            widgets.Label(label="Системний вивід активний", css_classes=["b-subtext"], halign="start")
        ])
    ])
    
    # Функція перемикання сторінок
    def switch_page(page_num):
        child = pages_stack.get_first_child()
        while child:
            pages_stack.remove(child)
            child = pages_stack.get_first_child()
        
        if page_num == 0:
            pages_stack.append(page1_content)
        else:
            # ВИПРАВЛЕНО: Додаємо кнопку тільки якщо її ще немає
            # Перевіряємо кількість дітей. Спочатку там тільки Label (1 елемент).
            # Якщо елементів більше 1, значить кнопка вже є.
            child_count = 0
            temp_child = page2_header.get_first_child()
            while temp_child:
                child_count += 1
                temp_child = temp_child.get_next_sibling()

            if child_count == 1:
                back_btn = ClickableBox(
                    child=widgets.Icon(image="go-previous-symbolic", pixel_size=20, style="color: #181825;"),
                    on_click=lambda x: switch_page(0),
                    style="background-color: #89b4fa; border-radius: 12px; padding: 2px; min-width: 5px; min-height: 5px;",
                    centered=True
                )
                page2_header.append(back_btn)
                
            pages_stack.append(page2_content)
    
    # Початково показуємо першу сторінку
    switch_page(0)
    
    # Створюємо вікно
    window = widgets.Window(
        name="control_center", 
        namespace="ignis", 
        anchor=["top", "right", "bottom"], 
        css_classes=["unset-window"], 
        visible=False,
        kb_mode="exclusive", 
        child=pages_stack
    )
    
    # Зберігаємо функцію перемикання як атрибут вікна
    window._switch_page = switch_page
    
    # Клавіатурні скорочення
    key_controller = Gtk.EventControllerKey()
    current_page = [0]
    
    def on_key_pressed(controller, keyval, keycode, state):
        if keyval == Gdk.KEY_Escape:
            window.visible = False
            return True
        elif keyval == Gdk.KEY_Page_Down or keyval == Gdk.KEY_Right:
            if current_page[0] == 0:
                switch_page(1)
                current_page[0] = 1
            return True
        elif keyval == Gdk.KEY_Page_Up or keyval == Gdk.KEY_Left:
            if current_page[0] == 1:
                switch_page(0)
                current_page[0] = 0
            return True
        return False
    
    key_controller.connect("key-pressed", on_key_pressed)
    window.add_controller(key_controller)
    
    return window

app.add_window(window=create_control_center(), window_name="control_center")

# --- Ініціалізація модулів ---
try: wallpapers.setup(app)
except: pass

try: switcher.setup(app)
except: pass

try: clipboard.setup(app)
except: pass

# [4] ДОДАНО: ІНІЦІАЛІЗАЦІЯ POWERMENU
try: powermenu.setup(app)
except: pass

try: launcher.setup(app)
except: pass

dock.create_dock()